# dokter-rasa-web
Restaurant Catalog accessible &amp; responsive website with pure CSS. Developed as a submission for Dicoding's "Menjadi Front-end Developer Expert" course
